"""
Gets raw text out of whatever format the user uploaded, and computes a
stable hash of the file's bytes so the caching layer can detect when the
projects file actually changed vs. was re-uploaded unchanged.
"""

import hashlib
from pathlib import Path

import pdfplumber
from docx import Document


def hash_file_bytes(file_bytes: bytes) -> str:
    """Stable content hash — same content always produces the same hash,
    regardless of filename or upload timestamp."""
    return hashlib.sha256(file_bytes).hexdigest()


def extract_text(file_path: str, file_bytes: bytes = None) -> str:
    """
    Extracts plain text from a PDF or .docx file.
    Pass file_bytes directly if reading from an in-memory upload (e.g.
    Streamlit's UploadedFile) rather than a path on disk.
    """
    suffix = Path(file_path).suffix.lower()

    if suffix == ".pdf":
        return _extract_pdf_text(file_path)
    elif suffix == ".docx":
        return _extract_docx_text(file_path)
    elif suffix == ".txt":
        return Path(file_path).read_text()
    else:
        raise ValueError(f"Unsupported file type: {suffix}. Use .pdf, .docx, or .txt")


def _extract_pdf_text(file_path: str) -> str:
    text_chunks = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text_chunks.append(page_text)
    return "\n\n".join(text_chunks)


def _extract_docx_text(file_path: str) -> str:
    doc = Document(file_path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())