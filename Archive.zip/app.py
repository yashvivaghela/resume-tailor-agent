"""
app.py — Streamlit UI for the grounded resume tailoring system.

This is a thin UI layer over the existing pipeline — no new agent
logic lives here. Every function called below (parse_projects_doc,
run_executor_on_docx, read_run_log) already exists and was already
tested independently; this file just wires them to a browser.

KNOWN SCOPE LIMIT: JD input is pasted text only. fetch_job_posting(url)
was planned in Phase 1 but never actually built, so URL input isn't
supported yet — noted here rather than silently missing.
"""

import tempfile
from pathlib import Path

import streamlit as st

from parse_projects import parse_projects_doc
from executor import run_executor_on_docx
from cache import load_cache
from logger import read_run_log

st.set_page_config(page_title="Grounded Resume Tailor", layout="wide")

st.title("Grounded Resume Tailor")
st.caption(
    "A multi-agent system that tailors your resume to a job description — "
    "every claim is independently verified against your real project data "
    "before it's accepted, and the system tells you honestly when it can't "
    "back something up, rather than guessing."
)

# ---------------------------------------------------------------------
# Step 1 — projects/experience doc (only needed once; cached after that)
# ---------------------------------------------------------------------
existing_cache = load_cache()

with st.expander(
    "1. Upload your projects + experience doc",
    expanded=(existing_cache is None),
):
    if existing_cache is not None:
        st.success(
            f"Using previously uploaded data — "
            f"{len(existing_cache['projects'])} entries loaded. "
            f"Upload a new file below only if you want to replace it."
        )

    projects_file = st.file_uploader(
        "PDF, DOCX, or TXT — a doc listing your Experience and Projects "
        "(see README for the expected format)",
        type=["pdf", "docx", "txt"],
        key="projects_upload",
    )

    if projects_file is not None:
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=Path(projects_file.name).suffix
        ) as tmp:
            tmp.write(projects_file.getvalue())
            tmp_path = tmp.name

        with st.spinner("Reading your projects doc..."):
            try:
                projects = parse_projects_doc(tmp_path)
                st.success(f"Loaded {len(projects)} entries from your doc.")
            except Exception as e:
                st.error(f"Couldn't parse that file: {e}")

# ---------------------------------------------------------------------
# Step 2 — resume + job description
# ---------------------------------------------------------------------
st.subheader("2. Upload your resume")
resume_file = st.file_uploader("Resume (.docx only)", type=["docx"], key="resume_upload")

st.subheader("3. Paste the job description")
jd_text = st.text_area(
    "Job description text",
    height=200,
    placeholder="Paste the full job posting text here...",
)
st.caption(
    "URL input isn't supported yet — paste the job description text directly."
)

can_run = resume_file is not None and jd_text.strip() and load_cache() is not None

if not can_run:
    missing = []
    if load_cache() is None:
        missing.append("a projects/experience doc")
    if resume_file is None:
        missing.append("a resume")
    if not jd_text.strip():
        missing.append("a job description")
    if missing:
        st.info(f"Still need: {', '.join(missing)}")

# ---------------------------------------------------------------------
# Step 3 — run the pipeline
# ---------------------------------------------------------------------
if "pipeline_results" not in st.session_state:
    st.session_state.pipeline_results = None

if st.button("Tailor my resume", disabled=not can_run, type="primary"):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp_resume:
        tmp_resume.write(resume_file.getvalue())
        resume_path = tmp_resume.name

    output_path = str(Path(tempfile.gettempdir()) / "tailored_resume.docx")

    pipeline_error = None
    with st.spinner(
        "Running the agent pipeline — this can take a minute or two "
        "(matching sections, drafting, fact-checking, scoring)..."
    ):
        try:
            results, run_id, fit = run_executor_on_docx(resume_path, jd_text, output_path)
        except Exception as e:
            # Don't call st.error()/st.stop() while still inside the
            # spinner block — doing so interrupts Streamlit mid-cleanup
            # of the spinner's UI element, leaving it visually "stuck"
            # showing as still running even though execution actually
            # halted underneath it. Capture the error, let the `with`
            # block exit NORMALLY first, then handle it outside.
            pipeline_error = str(e)

    if pipeline_error is not None:
        st.error(f"Something went wrong: {pipeline_error}")
        st.stop()

    # SAVE to session_state — this is what survives the rerun that
    # clicking the download button (or any other widget) triggers.
    # Local variables like `results`/`fit` here would otherwise vanish
    # the moment ANY widget is clicked again, since Streamlit reruns
    # the whole script from the top and this `if st.button(...)` block
    # would no longer be True on that rerun.
    with open(output_path, "rb") as f:
        docx_bytes = f.read()

    st.session_state.pipeline_results = {
        "results": results,
        "fit": fit,
        "run_id": run_id,
        "docx_bytes": docx_bytes,
    }

# ---------------------------------------------------------------------
# Display — reads from session_state, NOT from the button's click state.
# This is what makes it survive the rerun triggered by clicking
# Download (or the reasoning-trace expander, or anything else).
# ---------------------------------------------------------------------
if st.session_state.pipeline_results is not None:
    saved = st.session_state.pipeline_results
    results, fit, run_id, docx_bytes = (
        saved["results"], saved["fit"], saved["run_id"], saved["docx_bytes"]
    )

    st.success("Done.")

    # --- Fit Score ---
    st.subheader("Fit Score")
    col1, col2 = st.columns([1, 3])
    with col1:
        st.metric("Overall", fit.overall_score)
    with col2:
        st.write(fit.honest_note)

    fcol1, fcol2, fcol3 = st.columns(3)
    with fcol1:
        st.markdown("**Strong areas**")
        for a in fit.strong_areas:
            st.write(f"✅ {a}")
    with fcol2:
        st.markdown("**Weak areas**")
        for a in fit.weak_areas:
            st.write(f"⚠️ {a}")
    with fcol3:
        st.markdown("**Unaddressed**")
        for a in fit.unaddressed_requirements:
            st.write(f"❌ {a}")

    # --- Per-section results ---
    st.subheader("Section-by-section changes")
    for r in results:
        label = f"{r['section_name']} — {'REPLACED' if r['was_replaced'] else 'kept'}"
        with st.expander(label, expanded=True):
            st.caption(r["assignment_reason"])
            for b in r["final_bullets"]:
                st.write(f"• {b}")
            for g in r["gaps"]:
                st.warning(f"Not addressed — {g['requirement']}: {g['reason']}")

    # --- Download ---
    st.download_button(
        "Download tailored resume (.docx)",
        docx_bytes,
        file_name="tailored_resume.docx",
        type="primary",
    )

    # --- Reasoning trace ---
    with st.expander("Show full reasoning trace (every agent decision, in order)"):
        events = read_run_log(run_id)
        st.json(events)