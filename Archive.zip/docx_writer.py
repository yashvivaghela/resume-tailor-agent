"""
docx_writer.py — writes new text into an existing resume, safely.

Core safety guarantee: this NEVER adds or removes a paragraph, and
NEVER removes a run. It only ever changes the TEXT inside a run,
keeping every formatting property (font, size, bold, bullet style,
indentation) exactly as it was — because none of those live on the
text itself, they live on the paragraph/run objects, which are never
touched here.

Because paragraph count and run count are structurally guaranteed
unchanged by construction (not just checked after the fact), there's
no possibility of this silently corrupting the document's layout.
"""

from docx import Document


def replace_paragraph_text(paragraph, new_text: str) -> None:
    """
    Replaces a paragraph's visible text with new_text, in place.

    If the paragraph has multiple runs (e.g. part bold, part not), the
    new text goes entirely into the FIRST run — which keeps that run's
    formatting (font, size, bold, color) — and every other run's text
    is cleared to "" rather than deleted. This means: run count is
    unchanged, paragraph count is unchanged, only visible characters
    change. Mixed intra-paragraph formatting (e.g. one bolded word
    inside an otherwise normal sentence) is not preserved in that case
    — the whole new text takes on run 0's formatting — which is an
    acceptable, honest tradeoff for a resume bullet, where formatting
    is normally uniform across the whole line anyway.
    """
    if not paragraph.runs:
        # No runs at all (rare — an empty or field-only paragraph).
        # Nothing safe to edit; leave it alone rather than guessing.
        return

    paragraph.runs[0].text = new_text
    for run in paragraph.runs[1:]:
        run.text = ""


def write_tailored_docx(source_path: str, output_path: str, edits: dict[int, str]) -> None:
    """
    source_path: the ORIGINAL resume — opened read-only in effect,
                 since we only ever .save() to output_path, never back
                 to source_path.
    output_path: where the edited copy gets saved. Should be a NEW
                 filename (e.g. "tailored_resume_CompanyName.docx"),
                 never the same as source_path.
    edits: {paragraph_index: new_text} — exactly which paragraphs to
                 change and what to change them to. Every index here
                 must correspond to a title_index or one of the
                 bullet_indices from read_docx_sections().
    """
    doc = Document(source_path)
    original_paragraph_count = len(doc.paragraphs)

    for index, new_text in edits.items():
        if index >= len(doc.paragraphs):
            raise ValueError(
                f"Edit references paragraph index {index}, but the "
                f"document only has {len(doc.paragraphs)} paragraphs."
            )
        replace_paragraph_text(doc.paragraphs[index], new_text)

    # Verify the structural guarantee held — this should be impossible
    # to violate given replace_paragraph_text() never adds/removes
    # paragraphs, but checking costs nothing and catches any future
    # change to this file that might accidentally break that invariant.
    if len(doc.paragraphs) != original_paragraph_count:
        raise RuntimeError(
            f"Paragraph count changed during editing "
            f"({original_paragraph_count} -> {len(doc.paragraphs)}). "
            f"Aborting save — this should never happen."
        )

    doc.save(output_path)


# if __name__ == "__main__":
#     from docx_reader import extract_paragraph_structure

#     source = "data/test_resume_A_headings.docx"
#     output = "data/test_resume_A_TAILORED.docx"

#     # Confirm original paragraph 5 (a bullet under Personal Finance
#     # Dashboard) before editing, so we have something to compare against
#     before = extract_paragraph_structure(source)
#     print("Paragraph 5 BEFORE edit:")
#     print(f"  text: {before[5]['text']!r}")

#     # Edit just that one bullet
#     write_tailored_docx(source, output, {5: "Rewrote this bullet to prove the edit worked."})

#     after = extract_paragraph_structure(output)
#     print("\nParagraph 5 AFTER edit (in the OUTPUT file):")
#     print(f"  text: {after[5]['text']!r}")

#     print(f"\nParagraph count unchanged: {len(before) == len(after)}")

#     # Confirm every OTHER paragraph is untouched
#     untouched_ok = all(
#         before[i]["text"] == after[i]["text"]
#         for i in range(len(before)) if i != 5
#     )
#     print(f"All other paragraphs untouched: {untouched_ok}")

#     # Confirm the ORIGINAL file was never modified
#     original_still_intact = extract_paragraph_structure(source)[5]["text"] == before[5]["text"]
#     print(f"Original source file left untouched: {original_still_intact}")