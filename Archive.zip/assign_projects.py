"""
assign_projects_to_sections — the Project Assignment agent.

For each EXISTING section in the resume (with its current entry and
bullet count), decides whether that entry is still the strongest fit
for the JD, or whether a different entry from the full project/
experience list would serve better. This is a text-only swap (title +
bullets) — never a structural change to the resume — so it stays inside
the formatting-safety boundary from Phase 3's design.

IMPORTANT — what this function does NOT do:
- It does NOT draft or reword any bullets. draft_bullets() (Phase 2)
  runs on the RESULT of this step, unconditionally — for every assigned
  entry, whether it was replaced or kept. Assignment only decides WHICH
  entry fills a slot; the bullets always get freshly tailored to the JD
  regardless, since even a kept project's existing wording may not speak
  to this specific JD.
- `was_replaced` is metadata for two OTHER consumers downstream, not a
  signal about whether to redraft: (1) Phase 3's docx editor needs it to
  know whether it must also swap the section's title/project-name line,
  not just the bullets, and (2) the Fit Scorer's transparency report.

KNOWN GAP, to be resolved in Phase 3: in real usage, `resume_sections`
won't come with entry ids pre-attached — a real resume might say
"Personal Finance Tracker" while the projects doc says "Personal Finance
Dashboard." Phase 3 needs a separate matching step (fuzzy/semantic, not
exact string match) that maps each real resume section's title/bullets
to the corresponding cached entry id BEFORE this function can run on
real data. The test below hand-supplies ids to work around this for now.

If a resume section has no match in the projects doc at all, that does
NOT mean there's no ground truth — the section's OWN current bullets
are real, user-authored source material. Phase 3's matching step should
fall back to extracting those bullets verbatim as this section's
description, rather than treating an unmatched section as untouchable.
"""

import json

from llm_client import call_llm
from schemas import SectionAssignment, JDRequirements
from project_queries import list_projects

SYSTEM_PROMPT = """You decide which project or experience entry should
fill each section of a resume, given a target job description.

You'll be given:
1. The resume's CURRENT sections — each with a section name, its TYPE
   ("experience" or "project"), the entry currently filling it, and how
   many bullets that section has (this bullet count is FIXED — whatever
   entry you assign must work within that many bullets, you cannot add
   or remove sections)
2. The FULL list of available entries (both work experience and
   projects) the person could draw from — including ones not currently
   in the resume at all
3. The parsed job description requirements

For EACH section, decide: is the CURRENT entry still the strongest
available fit for this JD, or does a DIFFERENT entry from the full list
serve the JD better? You may only assign an entry that isn't already
used in another section — each entry can fill at most one section.

CRITICAL CONSTRAINT: a section's TYPE must never change. An
"experience" section (a real job) may ONLY be filled by another entry
whose type is "experience" — never by a "project." Likewise a "project"
section may ONLY be filled by another "project" entry. Mixing these
would put personal project content under a section literally titled
"Experience," misrepresenting it as paid work history — never do this,
even if a project would otherwise be a stronger content match for the
JD than any available experience entry.

Prefer keeping the current entry unless a genuinely stronger fit exists
— don't replace things just to be different. But don't be shy about
replacing a weak fit either: if a section holds an entry with little
relevance to this JD and a much more relevant entry of the SAME TYPE
exists elsewhere in the list, propose the swap.

Respond with ONLY a JSON array, one object per section, no other text,
no markdown code fences:
[
  {
    "section_name": "<matches the input section name exactly>",
    "assigned_entry_id": "<id of whichever entry now fills this slot>",
    "was_replaced": true | false,
    "reason": "<short explanation of why this entry was chosen or kept>"
  }
]
"""


def assign_projects_to_sections(
    resume_sections: list[dict],
    jd_requirements: JDRequirements,
) -> list[SectionAssignment]:
    """
    resume_sections: e.g.
        [{"section_name": "Project 1", "entry_type": "project",
          "current_entry_id": "proj_002", "bullet_count": 3}, ...]
        (this will come from read_docx_sections() once Phase 3 exists;
        for now it's passed in directly, e.g. from a hand-built test dict)

    entry_type on each section is REQUIRED — it's what enforces that an
    "experience" slot never gets filled by a "project" entry or vice
    versa (see CRITICAL CONSTRAINT in the prompt, and the code-level
    check below that doesn't just trust the prompt).
    """
    candidates = list_projects()  # cheap summaries: id, type, title, one_liner
    candidate_type_by_id = {c["id"]: c["type"] for c in candidates}
    section_type_by_name = {s["section_name"]: s["entry_type"] for s in resume_sections}

    user_message = (
        f"CURRENT RESUME SECTIONS:\n{json.dumps(resume_sections, indent=2)}\n\n"
        f"AVAILABLE ENTRIES (experience + projects):\n{json.dumps(candidates, indent=2)}\n\n"
        f"JOB REQUIREMENTS:\n{jd_requirements.model_dump_json(indent=2)}"
    )

    # Scale the token budget with how many sections are being assigned
    # — one JSON object per section, so more sections genuinely need
    # more room. A fixed 1500 was enough for our 5-section test set but
    # not for a real resume with more sections and a larger candidate
    # pool (longer per-section reasoning too).
    token_budget = 800 + (len(resume_sections) * 500)
    response_text = call_llm(SYSTEM_PROMPT, user_message, max_tokens=token_budget, context="assign_projects")

    cleaned = response_text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:]
    cleaned = cleaned.strip()

    try:
        raw_list = json.loads(cleaned)
    except json.JSONDecodeError as e:
        likely_truncated = not cleaned.rstrip().endswith("]")
        hint = (
            " This looks like TRUNCATION (response doesn't end with ']') "
            "— the token_budget may need to be higher for this many "
            "sections/candidates."
            if likely_truncated else ""
        )
        raise ValueError(
            f"Model didn't return valid JSON.{hint} Raw response:\n{response_text}"
        ) from e

    assignments = [SectionAssignment(**item) for item in raw_list]

    # DESIGN GUARANTEE, not just a convention: SectionAssignment only
    # carries an id, never text content. This is deliberate — it forces
    # whatever calls draft_bullets() next to fetch the FULL entry via
    # get_project_details(id), which returns the verbatim `description`
    # field. It structurally prevents accidentally reusing the one_liner
    # (an LLM paraphrase, used only for THIS function's own scanning/
    # decision-making) as if it were grounded source text. Do not add a
    # `description` or `one_liner` field to SectionAssignment later —
    # that would reopen this exact risk.
    #
    # Validate the "each entry used at most once" rule ourselves — the
    # prompt asks for this, but a prompt instruction is not a guarantee.
    # Fail loudly here rather than silently letting a resume claim the
    # same project twice under two different section headers.
    seen_entry_ids = {}
    for a in assignments:
        if a.assigned_entry_id in seen_entry_ids:
            raise ValueError(
                f"Model assigned entry '{a.assigned_entry_id}' to both "
                f"'{seen_entry_ids[a.assigned_entry_id]}' and "
                f"'{a.section_name}' — an entry can only fill one section."
            )
        seen_entry_ids[a.assigned_entry_id] = a.section_name

    # Enforce the type constraint ourselves too — don't just trust the
    # prompt. An "experience" section must be filled by an "experience"
    # entry, never a "project" (and vice versa), or the resume would
    # show project work under a heading that implies paid employment.
    for a in assignments:
        expected_type = section_type_by_name.get(a.section_name)
        actual_type = candidate_type_by_id.get(a.assigned_entry_id)
        if expected_type is not None and actual_type != expected_type:
            raise ValueError(
                f"Type mismatch: section '{a.section_name}' is type "
                f"'{expected_type}' but was assigned entry "
                f"'{a.assigned_entry_id}' (type '{actual_type}'). "
                f"An experience slot can never be filled by a project, "
                f"or vice versa."
            )

    return assignments


# if __name__ == "__main__":
#     from parse_jd import parse_jd

#     # Fake resume structure — stands in for what read_docx_sections()
#     # will provide once Phase 3 exists. Deliberately puts a weak-fit
#     # project (the weather bot) in a slot, to test whether the model
#     # actually proposes swapping it out for something more relevant.
#     fake_resume_sections = [
#         {"section_name": "Project 1", "entry_type": "project", "current_entry_id": "proj_003", "bullet_count": 2},
#         {"section_name": "Project 2", "entry_type": "project", "current_entry_id": "proj_002", "bullet_count": 3},
#     ]

#     sample_jd = """
#     Senior Backend Engineer

#     Requirements:
#     - 5+ years of experience with Python
#     - Experience designing and building REST APIs at scale
#     - Familiarity with automated testing and CI/CD practices
#     - Bachelor's degree in Computer Science or equivalent experience
#     """

#     jd = parse_jd(sample_jd)
#     assignments = assign_projects_to_sections(fake_resume_sections, jd)

#     for a in assignments:
#         print(a.model_dump_json(indent=2))